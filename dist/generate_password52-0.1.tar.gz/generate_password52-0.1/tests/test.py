import generate_password52 as ps

ps.
