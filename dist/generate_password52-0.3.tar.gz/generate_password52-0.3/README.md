# *This library is not that useful. Perhaps someday it will become great.*

## **Install**

To install, type in PowerShell:
```shell
pip install generate_password52
```



## **Set up a library for *corrective* work**
Import each module separately:
```python
from generate_password52 import password
```
